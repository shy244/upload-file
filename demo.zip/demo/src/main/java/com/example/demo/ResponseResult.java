package com.example.demo;

import java.io.Serializable;

public class ResponseResult implements Serializable {
    private int code;
    private String result;

    public ResponseResult() {
    }

    public ResponseResult(int code, String result) {
        this.code = code;
        this.result = result;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
