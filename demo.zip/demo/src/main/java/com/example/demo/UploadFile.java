package com.example.demo;


import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@RestController
public class UploadFile {
    @RequestMapping(value = "/uploadfile", method = RequestMethod.POST)
    public Object uploadFile(MultipartHttpServletRequest request) throws IOException {
        //这个方法获取的是 key为文件名，value为MultipartFile对象的Map
//        MultiValueMap<String, MultipartFile> map =  request.getMultiFileMap();


        //如果上传了多个文件可以通过这个方法获取所有上传文件的文件名Iterator对象，然后通过遍历获取文件名，取出文件
//        Iterator<String> ite = request.getFileNames();
//        while (ite.hasNext()) {
//            String name = ite.next();
//            System.out.println(name);
//        }



        //这里的file1是上传文件的input标签的name属性的值
        MultipartFile file =request.getFile("file1");


        // --上传文件是否空文件
        if (file == null) {
            return new ResponseResult(200, "上传文件为空");
        }

        String savePath = request.getServletContext().getRealPath("/WEB-INF/upload");
        //上传时生成的临时文件保存目录
        File directory  = new File(savePath);
        if (!directory .exists()) {
            //创建临时目录
            directory.mkdir();
        }


        String filename = file.getOriginalFilename();
        byte[] fileDatas = file.getBytes();



       BufferedOutputStream bs = new BufferedOutputStream(new FileOutputStream(savePath + "/" + filename));
        bs.write(fileDatas);
        bs.close();
        return new ResponseResult(200, "上传文件成功");
    }
}
